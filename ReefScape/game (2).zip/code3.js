gdjs.Level_323Code = {};
gdjs.Level_323Code.localVariables = [];
gdjs.Level_323Code.idToCallbackMap = new Map();
gdjs.Level_323Code.GDTrapdoorObjects1= [];
gdjs.Level_323Code.GDTrapdoorObjects2= [];
gdjs.Level_323Code.GDButtonObjects1= [];
gdjs.Level_323Code.GDButtonObjects2= [];
gdjs.Level_323Code.GDQuestionObjects1= [];
gdjs.Level_323Code.GDQuestionObjects2= [];
gdjs.Level_323Code.GDAnswerObjects1= [];
gdjs.Level_323Code.GDAnswerObjects2= [];
gdjs.Level_323Code.GDAnswer2Objects1= [];
gdjs.Level_323Code.GDAnswer2Objects2= [];
gdjs.Level_323Code.GDButton2Objects1= [];
gdjs.Level_323Code.GDButton2Objects2= [];
gdjs.Level_323Code.GDPlayerObjects1= [];
gdjs.Level_323Code.GDPlayerObjects2= [];
gdjs.Level_323Code.GDPlatformObjects1= [];
gdjs.Level_323Code.GDPlatformObjects2= [];
gdjs.Level_323Code.GDcoralObjects1= [];
gdjs.Level_323Code.GDcoralObjects2= [];
gdjs.Level_323Code.GDDumpsterObjects1= [];
gdjs.Level_323Code.GDDumpsterObjects2= [];
gdjs.Level_323Code.GDBackgroundObjects1= [];
gdjs.Level_323Code.GDBackgroundObjects2= [];
gdjs.Level_323Code.GDEnd_9595TextObjects1= [];
gdjs.Level_323Code.GDEnd_9595TextObjects2= [];
gdjs.Level_323Code.GDtutorial_9595doublejumpObjects1= [];
gdjs.Level_323Code.GDtutorial_9595doublejumpObjects2= [];
gdjs.Level_323Code.GDSpikesObjects1= [];
gdjs.Level_323Code.GDSpikesObjects2= [];
gdjs.Level_323Code.GDSpikes2Objects1= [];
gdjs.Level_323Code.GDSpikes2Objects2= [];


gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_323Code.GDPlayerObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDcoralObjects1Objects = Hashtable.newFrom({"coral": gdjs.Level_323Code.GDcoralObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_323Code.GDPlayerObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDDumpsterObjects1Objects = Hashtable.newFrom({"Dumpster": gdjs.Level_323Code.GDDumpsterObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_323Code.GDPlayerObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDButtonObjects1Objects = Hashtable.newFrom({"Button": gdjs.Level_323Code.GDButtonObjects1});
gdjs.Level_323Code.asyncCallback15809676 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Level_323Code.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.Level_323Code.GDAnswerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Answer2"), gdjs.Level_323Code.GDAnswer2Objects2);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 3", false);
}
{for(var i = 0, len = gdjs.Level_323Code.GDAnswerObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDAnswerObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level_323Code.GDAnswer2Objects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDAnswer2Objects2[i].deleteFromScene(runtimeScene);
}
}
gdjs.Level_323Code.localVariables.length = 0;
}
gdjs.Level_323Code.idToCallbackMap.set(15809676, gdjs.Level_323Code.asyncCallback15809676);
gdjs.Level_323Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Level_323Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Level_323Code.asyncCallback15809676(runtimeScene, asyncObjectsList)), 15809676, asyncObjectsList);
}
}

}


};gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_323Code.GDPlayerObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDButton2Objects1Objects = Hashtable.newFrom({"Button2": gdjs.Level_323Code.GDButton2Objects1});
gdjs.Level_323Code.asyncCallback15812404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Level_323Code.localVariables);
gdjs.Level_323Code.localVariables.length = 0;
}
gdjs.Level_323Code.idToCallbackMap.set(15812404, gdjs.Level_323Code.asyncCallback15812404);
gdjs.Level_323Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Level_323Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level_323Code.asyncCallback15812404(runtimeScene, asyncObjectsList)), 15812404, asyncObjectsList);
}
}

}


};gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_323Code.GDPlayerObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDButtonObjects1Objects = Hashtable.newFrom({"Button": gdjs.Level_323Code.GDButtonObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_323Code.GDPlayerObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDSpikesObjects1Objects = Hashtable.newFrom({"Spikes": gdjs.Level_323Code.GDSpikesObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_323Code.GDPlayerObjects1});
gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDButton2Objects1Objects = Hashtable.newFrom({"Button2": gdjs.Level_323Code.GDButton2Objects1});
gdjs.Level_323Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Text"), gdjs.Level_323Code.GDEnd_9595TextObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Background", 0);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{for(var i = 0, len = gdjs.Level_323Code.GDEnd_9595TextObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDEnd_9595TextObjects1[i].hide();
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "background.mp3", true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("coral"), gdjs.Level_323Code.GDcoralObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDcoralObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_323Code.GDcoralObjects1 */
{for(var i = 0, len = gdjs.Level_323Code.GDcoralObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDcoralObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() > 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Text"), gdjs.Level_323Code.GDEnd_9595TextObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDEnd_9595TextObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDEnd_9595TextObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dumpster"), gdjs.Level_323Code.GDDumpsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDDumpsterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 4", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button"), gdjs.Level_323Code.GDButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDButtonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_323Code.GDButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Question"), gdjs.Level_323Code.GDQuestionObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDButtonObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDButtonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Level_323Code.GDQuestionObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDQuestionObjects1[i].getBehavior("Text").setText("bruh");
}
}

{ //Subevents
gdjs.Level_323Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button2"), gdjs.Level_323Code.GDButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDButton2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.Level_323Code.GDAnswerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Answer2"), gdjs.Level_323Code.GDAnswer2Objects1);
/* Reuse gdjs.Level_323Code.GDButton2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Question"), gdjs.Level_323Code.GDQuestionObjects1);
gdjs.copyArray(runtimeScene.getObjects("Trapdoor"), gdjs.Level_323Code.GDTrapdoorObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDTrapdoorObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDTrapdoorObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level_323Code.GDButton2Objects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDButton2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Level_323Code.GDQuestionObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDQuestionObjects1[i].getBehavior("Text").setText("Correct!");
}
}
{for(var i = 0, len = gdjs.Level_323Code.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDAnswerObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level_323Code.GDAnswer2Objects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDAnswer2Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 3", false);
}

{ //Subevents
gdjs.Level_323Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button"), gdjs.Level_323Code.GDButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDButtonObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_323Code.GDButtonObjects1 */
{for(var i = 0, len = gdjs.Level_323Code.GDButtonObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDButtonObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spikes"), gdjs.Level_323Code.GDSpikesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDSpikesObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 3", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button2"), gdjs.Level_323Code.GDButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDPlayerObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_9546Level_9595323Code_9546GDButton2Objects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_323Code.GDButton2Objects1 */
{for(var i = 0, len = gdjs.Level_323Code.GDButton2Objects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDButton2Objects1[i].hide(false);
}
}
}

}


};

gdjs.Level_323Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_323Code.GDTrapdoorObjects1.length = 0;
gdjs.Level_323Code.GDTrapdoorObjects2.length = 0;
gdjs.Level_323Code.GDButtonObjects1.length = 0;
gdjs.Level_323Code.GDButtonObjects2.length = 0;
gdjs.Level_323Code.GDQuestionObjects1.length = 0;
gdjs.Level_323Code.GDQuestionObjects2.length = 0;
gdjs.Level_323Code.GDAnswerObjects1.length = 0;
gdjs.Level_323Code.GDAnswerObjects2.length = 0;
gdjs.Level_323Code.GDAnswer2Objects1.length = 0;
gdjs.Level_323Code.GDAnswer2Objects2.length = 0;
gdjs.Level_323Code.GDButton2Objects1.length = 0;
gdjs.Level_323Code.GDButton2Objects2.length = 0;
gdjs.Level_323Code.GDPlayerObjects1.length = 0;
gdjs.Level_323Code.GDPlayerObjects2.length = 0;
gdjs.Level_323Code.GDPlatformObjects1.length = 0;
gdjs.Level_323Code.GDPlatformObjects2.length = 0;
gdjs.Level_323Code.GDcoralObjects1.length = 0;
gdjs.Level_323Code.GDcoralObjects2.length = 0;
gdjs.Level_323Code.GDDumpsterObjects1.length = 0;
gdjs.Level_323Code.GDDumpsterObjects2.length = 0;
gdjs.Level_323Code.GDBackgroundObjects1.length = 0;
gdjs.Level_323Code.GDBackgroundObjects2.length = 0;
gdjs.Level_323Code.GDEnd_9595TextObjects1.length = 0;
gdjs.Level_323Code.GDEnd_9595TextObjects2.length = 0;
gdjs.Level_323Code.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.Level_323Code.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.Level_323Code.GDSpikesObjects1.length = 0;
gdjs.Level_323Code.GDSpikesObjects2.length = 0;
gdjs.Level_323Code.GDSpikes2Objects1.length = 0;
gdjs.Level_323Code.GDSpikes2Objects2.length = 0;

gdjs.Level_323Code.eventsList2(runtimeScene);
gdjs.Level_323Code.GDTrapdoorObjects1.length = 0;
gdjs.Level_323Code.GDTrapdoorObjects2.length = 0;
gdjs.Level_323Code.GDButtonObjects1.length = 0;
gdjs.Level_323Code.GDButtonObjects2.length = 0;
gdjs.Level_323Code.GDQuestionObjects1.length = 0;
gdjs.Level_323Code.GDQuestionObjects2.length = 0;
gdjs.Level_323Code.GDAnswerObjects1.length = 0;
gdjs.Level_323Code.GDAnswerObjects2.length = 0;
gdjs.Level_323Code.GDAnswer2Objects1.length = 0;
gdjs.Level_323Code.GDAnswer2Objects2.length = 0;
gdjs.Level_323Code.GDButton2Objects1.length = 0;
gdjs.Level_323Code.GDButton2Objects2.length = 0;
gdjs.Level_323Code.GDPlayerObjects1.length = 0;
gdjs.Level_323Code.GDPlayerObjects2.length = 0;
gdjs.Level_323Code.GDPlatformObjects1.length = 0;
gdjs.Level_323Code.GDPlatformObjects2.length = 0;
gdjs.Level_323Code.GDcoralObjects1.length = 0;
gdjs.Level_323Code.GDcoralObjects2.length = 0;
gdjs.Level_323Code.GDDumpsterObjects1.length = 0;
gdjs.Level_323Code.GDDumpsterObjects2.length = 0;
gdjs.Level_323Code.GDBackgroundObjects1.length = 0;
gdjs.Level_323Code.GDBackgroundObjects2.length = 0;
gdjs.Level_323Code.GDEnd_9595TextObjects1.length = 0;
gdjs.Level_323Code.GDEnd_9595TextObjects2.length = 0;
gdjs.Level_323Code.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.Level_323Code.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.Level_323Code.GDSpikesObjects1.length = 0;
gdjs.Level_323Code.GDSpikesObjects2.length = 0;
gdjs.Level_323Code.GDSpikes2Objects1.length = 0;
gdjs.Level_323Code.GDSpikes2Objects2.length = 0;


return;

}

gdjs['Level_323Code'] = gdjs.Level_323Code;
