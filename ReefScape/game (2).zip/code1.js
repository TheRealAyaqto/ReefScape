gdjs.Level_321_32TutorialCode = {};
gdjs.Level_321_32TutorialCode.localVariables = [];
gdjs.Level_321_32TutorialCode.idToCallbackMap = new Map();
gdjs.Level_321_32TutorialCode.GDTutorialObjects1= [];
gdjs.Level_321_32TutorialCode.GDTutorialObjects2= [];
gdjs.Level_321_32TutorialCode.GDPlayerObjects1= [];
gdjs.Level_321_32TutorialCode.GDPlayerObjects2= [];
gdjs.Level_321_32TutorialCode.GDPlatformObjects1= [];
gdjs.Level_321_32TutorialCode.GDPlatformObjects2= [];
gdjs.Level_321_32TutorialCode.GDcoralObjects1= [];
gdjs.Level_321_32TutorialCode.GDcoralObjects2= [];
gdjs.Level_321_32TutorialCode.GDDumpsterObjects1= [];
gdjs.Level_321_32TutorialCode.GDDumpsterObjects2= [];
gdjs.Level_321_32TutorialCode.GDBackgroundObjects1= [];
gdjs.Level_321_32TutorialCode.GDBackgroundObjects2= [];
gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects1= [];
gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects2= [];
gdjs.Level_321_32TutorialCode.GDtutorial_9595doublejumpObjects1= [];
gdjs.Level_321_32TutorialCode.GDtutorial_9595doublejumpObjects2= [];
gdjs.Level_321_32TutorialCode.GDSpikesObjects1= [];
gdjs.Level_321_32TutorialCode.GDSpikesObjects2= [];
gdjs.Level_321_32TutorialCode.GDSpikes2Objects1= [];
gdjs.Level_321_32TutorialCode.GDSpikes2Objects2= [];


gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_321_32TutorialCode.GDPlayerObjects1});
gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDcoralObjects1Objects = Hashtable.newFrom({"coral": gdjs.Level_321_32TutorialCode.GDcoralObjects1});
gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_321_32TutorialCode.GDPlayerObjects1});
gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDDumpsterObjects1Objects = Hashtable.newFrom({"Dumpster": gdjs.Level_321_32TutorialCode.GDDumpsterObjects1});
gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_321_32TutorialCode.GDPlayerObjects1});
gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDSpikesObjects1Objects = Hashtable.newFrom({"Spikes": gdjs.Level_321_32TutorialCode.GDSpikesObjects1});
gdjs.Level_321_32TutorialCode.asyncCallback15747780 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Level_321_32TutorialCode.localVariables);
gdjs.Level_321_32TutorialCode.localVariables.length = 0;
}
gdjs.Level_321_32TutorialCode.idToCallbackMap.set(15747780, gdjs.Level_321_32TutorialCode.asyncCallback15747780);
gdjs.Level_321_32TutorialCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Level_321_32TutorialCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level_321_32TutorialCode.asyncCallback15747780(runtimeScene, asyncObjectsList)), 15747780, asyncObjectsList);
}
}

}


};gdjs.Level_321_32TutorialCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Text"), gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Background", 0);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{for(var i = 0, len = gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects1.length ;i < len;++i) {
    gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects1[i].hide();
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level 1 timer");
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "background.mp3", true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321_32TutorialCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("coral"), gdjs.Level_321_32TutorialCode.GDcoralObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDPlayerObjects1Objects, gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDcoralObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Tutorial"), gdjs.Level_321_32TutorialCode.GDTutorialObjects1);
/* Reuse gdjs.Level_321_32TutorialCode.GDcoralObjects1 */
{for(var i = 0, len = gdjs.Level_321_32TutorialCode.GDcoralObjects1.length ;i < len;++i) {
    gdjs.Level_321_32TutorialCode.GDcoralObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{for(var i = 0, len = gdjs.Level_321_32TutorialCode.GDTutorialObjects1.length ;i < len;++i) {
    gdjs.Level_321_32TutorialCode.GDTutorialObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Text"), gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects1);
{for(var i = 0, len = gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects1.length ;i < len;++i) {
    gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dumpster"), gdjs.Level_321_32TutorialCode.GDDumpsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321_32TutorialCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDPlayerObjects1Objects, gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDDumpsterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 2", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321_32TutorialCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spikes"), gdjs.Level_321_32TutorialCode.GDSpikesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDPlayerObjects1Objects, gdjs.Level_321_32TutorialCode.mapOfGDgdjs_9546Level_9595321_959532TutorialCode_9546GDSpikesObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 1 Tutorial", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 1 Tutorial", false);
}

{ //Subevents
gdjs.Level_321_32TutorialCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.Level_321_32TutorialCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_321_32TutorialCode.GDTutorialObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDTutorialObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDPlayerObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDPlayerObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDPlatformObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDPlatformObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDcoralObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDcoralObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDDumpsterObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDDumpsterObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDBackgroundObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDBackgroundObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDSpikesObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDSpikesObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDSpikes2Objects1.length = 0;
gdjs.Level_321_32TutorialCode.GDSpikes2Objects2.length = 0;

gdjs.Level_321_32TutorialCode.eventsList1(runtimeScene);
gdjs.Level_321_32TutorialCode.GDTutorialObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDTutorialObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDPlayerObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDPlayerObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDPlatformObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDPlatformObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDcoralObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDcoralObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDDumpsterObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDDumpsterObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDBackgroundObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDBackgroundObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDEnd_9595TextObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDSpikesObjects1.length = 0;
gdjs.Level_321_32TutorialCode.GDSpikesObjects2.length = 0;
gdjs.Level_321_32TutorialCode.GDSpikes2Objects1.length = 0;
gdjs.Level_321_32TutorialCode.GDSpikes2Objects2.length = 0;


return;

}

gdjs['Level_321_32TutorialCode'] = gdjs.Level_321_32TutorialCode;
