gdjs.Level_324Code = {};
gdjs.Level_324Code.localVariables = [];
gdjs.Level_324Code.idToCallbackMap = new Map();
gdjs.Level_324Code.GDPlayerObjects1= [];
gdjs.Level_324Code.GDPlayerObjects2= [];
gdjs.Level_324Code.GDPlatformObjects1= [];
gdjs.Level_324Code.GDPlatformObjects2= [];
gdjs.Level_324Code.GDcoralObjects1= [];
gdjs.Level_324Code.GDcoralObjects2= [];
gdjs.Level_324Code.GDDumpsterObjects1= [];
gdjs.Level_324Code.GDDumpsterObjects2= [];
gdjs.Level_324Code.GDBackgroundObjects1= [];
gdjs.Level_324Code.GDBackgroundObjects2= [];
gdjs.Level_324Code.GDEnd_9595TextObjects1= [];
gdjs.Level_324Code.GDEnd_9595TextObjects2= [];
gdjs.Level_324Code.GDtutorial_9595doublejumpObjects1= [];
gdjs.Level_324Code.GDtutorial_9595doublejumpObjects2= [];
gdjs.Level_324Code.GDSpikesObjects1= [];
gdjs.Level_324Code.GDSpikesObjects2= [];
gdjs.Level_324Code.GDSpikes2Objects1= [];
gdjs.Level_324Code.GDSpikes2Objects2= [];


gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_324Code.GDPlayerObjects1});
gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDcoralObjects1Objects = Hashtable.newFrom({"coral": gdjs.Level_324Code.GDcoralObjects1});
gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_324Code.GDPlayerObjects1});
gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDDumpsterObjects1Objects = Hashtable.newFrom({"Dumpster": gdjs.Level_324Code.GDDumpsterObjects1});
gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_324Code.GDPlayerObjects1});
gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDSpikesObjects1Objects = Hashtable.newFrom({"Spikes": gdjs.Level_324Code.GDSpikesObjects1});
gdjs.Level_324Code.asyncCallback15839772 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Level_324Code.localVariables);
gdjs.Level_324Code.localVariables.length = 0;
}
gdjs.Level_324Code.idToCallbackMap.set(15839772, gdjs.Level_324Code.asyncCallback15839772);
gdjs.Level_324Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Level_324Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level_324Code.asyncCallback15839772(runtimeScene, asyncObjectsList)), 15839772, asyncObjectsList);
}
}

}


};gdjs.Level_324Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Text"), gdjs.Level_324Code.GDEnd_9595TextObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Background", 0);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{for(var i = 0, len = gdjs.Level_324Code.GDEnd_9595TextObjects1.length ;i < len;++i) {
    gdjs.Level_324Code.GDEnd_9595TextObjects1[i].hide();
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "background.mp3", true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_324Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("coral"), gdjs.Level_324Code.GDcoralObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDPlayerObjects1Objects, gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDcoralObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_324Code.GDcoralObjects1 */
{for(var i = 0, len = gdjs.Level_324Code.GDcoralObjects1.length ;i < len;++i) {
    gdjs.Level_324Code.GDcoralObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 7);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Text"), gdjs.Level_324Code.GDEnd_9595TextObjects1);
{for(var i = 0, len = gdjs.Level_324Code.GDEnd_9595TextObjects1.length ;i < len;++i) {
    gdjs.Level_324Code.GDEnd_9595TextObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dumpster"), gdjs.Level_324Code.GDDumpsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_324Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDPlayerObjects1Objects, gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDDumpsterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 7);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 5", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_324Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spikes"), gdjs.Level_324Code.GDSpikesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDPlayerObjects1Objects, gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDSpikesObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 4", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 4", false);
}

{ //Subevents
gdjs.Level_324Code.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.Level_324Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_324Code.GDPlayerObjects1.length = 0;
gdjs.Level_324Code.GDPlayerObjects2.length = 0;
gdjs.Level_324Code.GDPlatformObjects1.length = 0;
gdjs.Level_324Code.GDPlatformObjects2.length = 0;
gdjs.Level_324Code.GDcoralObjects1.length = 0;
gdjs.Level_324Code.GDcoralObjects2.length = 0;
gdjs.Level_324Code.GDDumpsterObjects1.length = 0;
gdjs.Level_324Code.GDDumpsterObjects2.length = 0;
gdjs.Level_324Code.GDBackgroundObjects1.length = 0;
gdjs.Level_324Code.GDBackgroundObjects2.length = 0;
gdjs.Level_324Code.GDEnd_9595TextObjects1.length = 0;
gdjs.Level_324Code.GDEnd_9595TextObjects2.length = 0;
gdjs.Level_324Code.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.Level_324Code.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.Level_324Code.GDSpikesObjects1.length = 0;
gdjs.Level_324Code.GDSpikesObjects2.length = 0;
gdjs.Level_324Code.GDSpikes2Objects1.length = 0;
gdjs.Level_324Code.GDSpikes2Objects2.length = 0;

gdjs.Level_324Code.eventsList1(runtimeScene);
gdjs.Level_324Code.GDPlayerObjects1.length = 0;
gdjs.Level_324Code.GDPlayerObjects2.length = 0;
gdjs.Level_324Code.GDPlatformObjects1.length = 0;
gdjs.Level_324Code.GDPlatformObjects2.length = 0;
gdjs.Level_324Code.GDcoralObjects1.length = 0;
gdjs.Level_324Code.GDcoralObjects2.length = 0;
gdjs.Level_324Code.GDDumpsterObjects1.length = 0;
gdjs.Level_324Code.GDDumpsterObjects2.length = 0;
gdjs.Level_324Code.GDBackgroundObjects1.length = 0;
gdjs.Level_324Code.GDBackgroundObjects2.length = 0;
gdjs.Level_324Code.GDEnd_9595TextObjects1.length = 0;
gdjs.Level_324Code.GDEnd_9595TextObjects2.length = 0;
gdjs.Level_324Code.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.Level_324Code.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.Level_324Code.GDSpikesObjects1.length = 0;
gdjs.Level_324Code.GDSpikesObjects2.length = 0;
gdjs.Level_324Code.GDSpikes2Objects1.length = 0;
gdjs.Level_324Code.GDSpikes2Objects2.length = 0;


return;

}

gdjs['Level_324Code'] = gdjs.Level_324Code;
