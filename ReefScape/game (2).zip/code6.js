gdjs.EndCode = {};
gdjs.EndCode.localVariables = [];
gdjs.EndCode.idToCallbackMap = new Map();
gdjs.EndCode.GDQuestionObjects1= [];
gdjs.EndCode.GDQuestionObjects2= [];
gdjs.EndCode.GDPlayerObjects1= [];
gdjs.EndCode.GDPlayerObjects2= [];
gdjs.EndCode.GDPlatformObjects1= [];
gdjs.EndCode.GDPlatformObjects2= [];
gdjs.EndCode.GDcoralObjects1= [];
gdjs.EndCode.GDcoralObjects2= [];
gdjs.EndCode.GDDumpsterObjects1= [];
gdjs.EndCode.GDDumpsterObjects2= [];
gdjs.EndCode.GDBackgroundObjects1= [];
gdjs.EndCode.GDBackgroundObjects2= [];
gdjs.EndCode.GDEnd_9595TextObjects1= [];
gdjs.EndCode.GDEnd_9595TextObjects2= [];
gdjs.EndCode.GDtutorial_9595doublejumpObjects1= [];
gdjs.EndCode.GDtutorial_9595doublejumpObjects2= [];
gdjs.EndCode.GDSpikesObjects1= [];
gdjs.EndCode.GDSpikesObjects2= [];
gdjs.EndCode.GDSpikes2Objects1= [];
gdjs.EndCode.GDSpikes2Objects2= [];


gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.EndCode.GDPlayerObjects1});
gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDcoralObjects1Objects = Hashtable.newFrom({"coral": gdjs.EndCode.GDcoralObjects1});
gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.EndCode.GDPlayerObjects1});
gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDDumpsterObjects1Objects = Hashtable.newFrom({"Dumpster": gdjs.EndCode.GDDumpsterObjects1});
gdjs.EndCode.asyncCallback15956300 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.EndCode.localVariables);
gdjs.EndCode.localVariables.length = 0;
}
gdjs.EndCode.idToCallbackMap.set(15956300, gdjs.EndCode.asyncCallback15956300);
gdjs.EndCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.EndCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.EndCode.asyncCallback15956300(runtimeScene, asyncObjectsList)), 15956300, asyncObjectsList);
}
}

}


};gdjs.EndCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Text"), gdjs.EndCode.GDEnd_9595TextObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Background", 0);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{for(var i = 0, len = gdjs.EndCode.GDEnd_9595TextObjects1.length ;i < len;++i) {
    gdjs.EndCode.GDEnd_9595TextObjects1[i].hide();
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "background.mp3", true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.EndCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("coral"), gdjs.EndCode.GDcoralObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDPlayerObjects1Objects, gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDcoralObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.EndCode.GDcoralObjects1 */
{for(var i = 0, len = gdjs.EndCode.GDcoralObjects1.length ;i < len;++i) {
    gdjs.EndCode.GDcoralObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Text"), gdjs.EndCode.GDEnd_9595TextObjects1);
{for(var i = 0, len = gdjs.EndCode.GDEnd_9595TextObjects1.length ;i < len;++i) {
    gdjs.EndCode.GDEnd_9595TextObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dumpster"), gdjs.EndCode.GDDumpsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.EndCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDPlayerObjects1Objects, gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDDumpsterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 3", false);
}

{ //Subevents
gdjs.EndCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.EndCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EndCode.GDQuestionObjects1.length = 0;
gdjs.EndCode.GDQuestionObjects2.length = 0;
gdjs.EndCode.GDPlayerObjects1.length = 0;
gdjs.EndCode.GDPlayerObjects2.length = 0;
gdjs.EndCode.GDPlatformObjects1.length = 0;
gdjs.EndCode.GDPlatformObjects2.length = 0;
gdjs.EndCode.GDcoralObjects1.length = 0;
gdjs.EndCode.GDcoralObjects2.length = 0;
gdjs.EndCode.GDDumpsterObjects1.length = 0;
gdjs.EndCode.GDDumpsterObjects2.length = 0;
gdjs.EndCode.GDBackgroundObjects1.length = 0;
gdjs.EndCode.GDBackgroundObjects2.length = 0;
gdjs.EndCode.GDEnd_9595TextObjects1.length = 0;
gdjs.EndCode.GDEnd_9595TextObjects2.length = 0;
gdjs.EndCode.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.EndCode.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.EndCode.GDSpikesObjects1.length = 0;
gdjs.EndCode.GDSpikesObjects2.length = 0;
gdjs.EndCode.GDSpikes2Objects1.length = 0;
gdjs.EndCode.GDSpikes2Objects2.length = 0;

gdjs.EndCode.eventsList1(runtimeScene);
gdjs.EndCode.GDQuestionObjects1.length = 0;
gdjs.EndCode.GDQuestionObjects2.length = 0;
gdjs.EndCode.GDPlayerObjects1.length = 0;
gdjs.EndCode.GDPlayerObjects2.length = 0;
gdjs.EndCode.GDPlatformObjects1.length = 0;
gdjs.EndCode.GDPlatformObjects2.length = 0;
gdjs.EndCode.GDcoralObjects1.length = 0;
gdjs.EndCode.GDcoralObjects2.length = 0;
gdjs.EndCode.GDDumpsterObjects1.length = 0;
gdjs.EndCode.GDDumpsterObjects2.length = 0;
gdjs.EndCode.GDBackgroundObjects1.length = 0;
gdjs.EndCode.GDBackgroundObjects2.length = 0;
gdjs.EndCode.GDEnd_9595TextObjects1.length = 0;
gdjs.EndCode.GDEnd_9595TextObjects2.length = 0;
gdjs.EndCode.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.EndCode.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.EndCode.GDSpikesObjects1.length = 0;
gdjs.EndCode.GDSpikesObjects2.length = 0;
gdjs.EndCode.GDSpikes2Objects1.length = 0;
gdjs.EndCode.GDSpikes2Objects2.length = 0;


return;

}

gdjs['EndCode'] = gdjs.EndCode;
