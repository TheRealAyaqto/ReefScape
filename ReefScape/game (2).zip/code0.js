gdjs.Main_32MenuCode = {};
gdjs.Main_32MenuCode.localVariables = [];
gdjs.Main_32MenuCode.idToCallbackMap = new Map();
gdjs.Main_32MenuCode.GDTitleObjects1= [];
gdjs.Main_32MenuCode.GDTitleObjects2= [];
gdjs.Main_32MenuCode.GDTitle2Objects1= [];
gdjs.Main_32MenuCode.GDTitle2Objects2= [];
gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1= [];
gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects2= [];
gdjs.Main_32MenuCode.GDPlayerObjects1= [];
gdjs.Main_32MenuCode.GDPlayerObjects2= [];
gdjs.Main_32MenuCode.GDPlatformObjects1= [];
gdjs.Main_32MenuCode.GDPlatformObjects2= [];
gdjs.Main_32MenuCode.GDcoralObjects1= [];
gdjs.Main_32MenuCode.GDcoralObjects2= [];
gdjs.Main_32MenuCode.GDDumpsterObjects1= [];
gdjs.Main_32MenuCode.GDDumpsterObjects2= [];
gdjs.Main_32MenuCode.GDBackgroundObjects1= [];
gdjs.Main_32MenuCode.GDBackgroundObjects2= [];
gdjs.Main_32MenuCode.GDEnd_9595TextObjects1= [];
gdjs.Main_32MenuCode.GDEnd_9595TextObjects2= [];
gdjs.Main_32MenuCode.GDtutorial_9595doublejumpObjects1= [];
gdjs.Main_32MenuCode.GDtutorial_9595doublejumpObjects2= [];
gdjs.Main_32MenuCode.GDSpikesObjects1= [];
gdjs.Main_32MenuCode.GDSpikesObjects2= [];
gdjs.Main_32MenuCode.GDSpikes2Objects1= [];
gdjs.Main_32MenuCode.GDSpikes2Objects2= [];


gdjs.Main_32MenuCode.asyncCallback15714908 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 1 Tutorial", false);
}
gdjs.Main_32MenuCode.localVariables.length = 0;
}
gdjs.Main_32MenuCode.idToCallbackMap.set(15714908, gdjs.Main_32MenuCode.asyncCallback15714908);
gdjs.Main_32MenuCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback15714908(runtimeScene, asyncObjectsList)), 15714908, asyncObjectsList);
}
}

}


};gdjs.Main_32MenuCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.preloadSound(runtimeScene, "spongebob-bubble-transition.mp3");
}
{gdjs.evtTools.sound.preloadMusic(runtimeScene, "background.mp3");
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "background.mp3", true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TransparentButtonWithWhiteBlueBorder"), gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[k] = gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "spongebob-bubble-transition.mp3", false, 100, 1);
}

{ //Subevents
gdjs.Main_32MenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.Main_32MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32MenuCode.GDTitleObjects1.length = 0;
gdjs.Main_32MenuCode.GDTitleObjects2.length = 0;
gdjs.Main_32MenuCode.GDTitle2Objects1.length = 0;
gdjs.Main_32MenuCode.GDTitle2Objects2.length = 0;
gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = 0;
gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects2.length = 0;
gdjs.Main_32MenuCode.GDPlayerObjects1.length = 0;
gdjs.Main_32MenuCode.GDPlayerObjects2.length = 0;
gdjs.Main_32MenuCode.GDPlatformObjects1.length = 0;
gdjs.Main_32MenuCode.GDPlatformObjects2.length = 0;
gdjs.Main_32MenuCode.GDcoralObjects1.length = 0;
gdjs.Main_32MenuCode.GDcoralObjects2.length = 0;
gdjs.Main_32MenuCode.GDDumpsterObjects1.length = 0;
gdjs.Main_32MenuCode.GDDumpsterObjects2.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects1.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects2.length = 0;
gdjs.Main_32MenuCode.GDEnd_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDEnd_9595TextObjects2.length = 0;
gdjs.Main_32MenuCode.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.Main_32MenuCode.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.Main_32MenuCode.GDSpikesObjects1.length = 0;
gdjs.Main_32MenuCode.GDSpikesObjects2.length = 0;
gdjs.Main_32MenuCode.GDSpikes2Objects1.length = 0;
gdjs.Main_32MenuCode.GDSpikes2Objects2.length = 0;

gdjs.Main_32MenuCode.eventsList1(runtimeScene);
gdjs.Main_32MenuCode.GDTitleObjects1.length = 0;
gdjs.Main_32MenuCode.GDTitleObjects2.length = 0;
gdjs.Main_32MenuCode.GDTitle2Objects1.length = 0;
gdjs.Main_32MenuCode.GDTitle2Objects2.length = 0;
gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = 0;
gdjs.Main_32MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects2.length = 0;
gdjs.Main_32MenuCode.GDPlayerObjects1.length = 0;
gdjs.Main_32MenuCode.GDPlayerObjects2.length = 0;
gdjs.Main_32MenuCode.GDPlatformObjects1.length = 0;
gdjs.Main_32MenuCode.GDPlatformObjects2.length = 0;
gdjs.Main_32MenuCode.GDcoralObjects1.length = 0;
gdjs.Main_32MenuCode.GDcoralObjects2.length = 0;
gdjs.Main_32MenuCode.GDDumpsterObjects1.length = 0;
gdjs.Main_32MenuCode.GDDumpsterObjects2.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects1.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects2.length = 0;
gdjs.Main_32MenuCode.GDEnd_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDEnd_9595TextObjects2.length = 0;
gdjs.Main_32MenuCode.GDtutorial_9595doublejumpObjects1.length = 0;
gdjs.Main_32MenuCode.GDtutorial_9595doublejumpObjects2.length = 0;
gdjs.Main_32MenuCode.GDSpikesObjects1.length = 0;
gdjs.Main_32MenuCode.GDSpikesObjects2.length = 0;
gdjs.Main_32MenuCode.GDSpikes2Objects1.length = 0;
gdjs.Main_32MenuCode.GDSpikes2Objects2.length = 0;


return;

}

gdjs['Main_32MenuCode'] = gdjs.Main_32MenuCode;
